var searchData=
[
  ['setmensaje_5',['setMensaje',['../class_socket_server.html#a8558a9d8f423f28c3c0e74eed03657e1',1,'SocketServer']]],
  ['socketserver_6',['SocketServer',['../class_socket_server.html',1,'SocketServer'],['../class_socket_server.html#a262ba93dc8ad71b260fb75124b3453ee',1,'SocketServer::SocketServer()']]],
  ['socketserver_2eh_7',['SocketServer.h',['../_socket_server_8h.html',1,'']]]
];
