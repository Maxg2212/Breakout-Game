var searchData=
[
  ['contoladorcliente_11',['ContoladorCliente',['../class_socket_server.html#a0fb1a1865d6ac0f580b9d56c0419a3ec',1,'SocketServer']]],
  ['crear_5fsocket_12',['crear_socket',['../class_socket_server.html#aae1913e5ec28288a1c937a105cd7136c',1,'SocketServer']]]
];
