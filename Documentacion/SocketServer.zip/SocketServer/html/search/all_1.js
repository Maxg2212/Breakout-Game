var searchData=
[
  ['datasocket_2',['dataSocket',['../structdata_socket.html',1,'']]]
];
