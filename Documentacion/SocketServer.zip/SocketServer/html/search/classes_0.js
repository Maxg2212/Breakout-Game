var searchData=
[
  ['datasocket_8',['dataSocket',['../structdata_socket.html',1,'']]]
];
