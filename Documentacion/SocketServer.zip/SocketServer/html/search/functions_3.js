var searchData=
[
  ['setmensaje_15',['setMensaje',['../class_socket_server.html#a8558a9d8f423f28c3c0e74eed03657e1',1,'SocketServer']]],
  ['socketserver_16',['SocketServer',['../class_socket_server.html#a262ba93dc8ad71b260fb75124b3453ee',1,'SocketServer']]]
];
